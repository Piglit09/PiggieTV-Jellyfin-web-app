import escapeHtml from 'escape-html';

import cardBuilder from 'components/cardbuilder/cardBuilder';
import imageLoader from 'components/images/imageLoader';
import { ServerConnections } from 'lib/jellyfin-apiclient';
import { getFeaturedContent } from 'ptv/modules/cache/featuredContentCache';
import { loadHeroItems } from 'ptv/modules/hero/useHeroItems';
import { getBackdropShape, getPortraitShape, getSquareShape } from 'utils/card';

const ROW_ITEM_LIMIT = 16;
const MEDIA_FIELDS = 'PrimaryImageAspectRatio,Path,MediaSources,MediaSourceCount,Genres,DateCreated,PremiereDate,ProductionYear,CommunityRating,CriticRating';
let backdropSeed = Date.now();

export const PTV_HOME_ROWS = [
    { id: 'my-media', title: 'My Media', type: 'libraries' },
    { id: 'continue-watching', title: 'Continue Watching', type: 'continue' },
    { id: 'latest-shows', title: 'Latest Shows', type: 'latest', itemTypes: 'Series', shape: 'portrait' },
    { id: 'latest-movies', title: 'Latest Movies', type: 'latest', itemTypes: 'Movie', shape: 'portrait' },
    { id: 'latest-music', title: 'Latest Music', type: 'latest', itemTypes: 'MusicAlbum', shape: 'square' },
    { id: 'horror', title: 'Horror', type: 'genre', genres: ['Horror'] },
    { id: 'comedy', title: 'Comedy', type: 'genre', genres: ['Comedy'] },
    { id: 'family-animation', title: 'Family Animation', type: 'genre', genres: ['Family', 'Animation'] },
    { id: 'drama', title: 'Drama', type: 'genre', genres: ['Drama'] },
    { id: 'science-fiction', title: 'Science Fiction', type: 'genre', genres: ['Science Fiction', 'Sci-Fi', 'Sci Fi'] },
    { id: 'anime', title: 'Anime', type: 'library', libraryNames: ['anime'], itemTypes: 'Movie,Series' },
    {
        id: 'music',
        title: 'Music',
        type: 'library',
        libraryNames: ['music'],
        itemTypes: 'MusicAlbum',
        shape: 'square',
        sortBy: 'CommunityRating,SortName',
        sortOrder: 'Descending'
    },
    { id: 'family', title: 'Family', type: 'genre', genres: ['Family'] },
    { id: 'action', title: 'Action', type: 'genre', genres: ['Action'] },
    {
        id: 'disney',
        title: 'Disney',
        type: 'search',
        searchTerms: [
            'disney',
            'walt disney',
            'walt disney feature animation',
            'walt disney pictures',
            'pixar',
            'disney channel',
            'disney junior'
        ],
        studioNames: ['Walt Disney Feature Animation', 'Walt Disney Pictures']
    },
    { id: 'marvel', title: 'Marvel', type: 'search', searchTerm: 'marvel' },
    { id: 'star-wars', title: 'Star Wars', type: 'search', searchTerm: 'star wars' },
    { id: 'star-trek', title: 'Star Trek', type: 'search', searchTerm: 'star trek' },
    { id: 'adult-animation', title: 'Adult Animation', type: 'search', searchTerm: 'adult animation' },
    { id: 'crime', title: 'Crime', type: 'genre', genres: ['Crime'] }
];

function hasRenderableImage(item) {
    return Boolean(
        item?.ImageTags?.Primary
        || item?.ImageTags?.Backdrop
        || item?.ImageTags?.Thumb
        || item?.ImageTags?.Banner
        || item?.PrimaryImageTag
        || item?.SeriesPrimaryImageTag
        || item?.ParentPrimaryImageTag
        || item?.AlbumPrimaryImageTag
        || item?.BackdropImageTags?.length
        || item?.ParentBackdropImageTags?.length
        || item?.SeriesThumbImageTag
        || item?.ParentThumbImageTag
    );
}

function getItems(result) {
    return result?.Items || result || [];
}

function getUniqueItems(items) {
    const usedKeys = new Set();

    return (items || []).filter(item => {
        const key = item.Id || item.ItemId || `${item.Name || ''}-${item.ProductionYear || ''}`;

        if (!key || usedKeys.has(key)) return false;

        usedKeys.add(key);
        return true;
    });
}

function getItemsFromResults(results) {
    const items = [];

    results.forEach(result => {
        items.push(...getItems(result));
    });

    return items;
}

function getGenreIds(row, genresByName) {
    return (row.genres || [])
        .map(genreName => genresByName.get(genreName.toLowerCase()))
        .filter(Boolean)
        .join(',');
}

function getPrimaryGenreId(row, genresByName) {
    return (row.genres || [])
        .map(genreName => genresByName.get(genreName.toLowerCase()))
        .find(Boolean) || '';
}

function getGenreUrl(row, genresByName, serverId) {
    if (row.type !== 'genre') return '';

    const genreId = getPrimaryGenreId(row, genresByName);
    if (!genreId || !serverId) return '';

    return `#/list?genreId=${encodeURIComponent(genreId)}&serverId=${encodeURIComponent(serverId)}`;
}

function getRowUrl(row, genresByName, serverId) {
    if (row.type === 'continue' || !serverId) return '';

    if (row.type === 'genre') {
        return getGenreUrl(row, genresByName, serverId);
    }

    if (row.type === 'latest' && row.itemTypes) {
        return `#/list?serverId=${encodeURIComponent(serverId)}&type=${encodeURIComponent(row.itemTypes)}`;
    }

    if (row.type === 'library' && row.parentId) {
        return `#/list?parentId=${encodeURIComponent(row.parentId)}&serverId=${encodeURIComponent(serverId)}`;
    }

    if (row.type === 'search') {
        const searchTerm = row.searchTerm || row.searchTerms?.[0] || row.title;

        return `#/search?query=${encodeURIComponent(searchTerm)}`;
    }

    return '';
}

function getStudioIds(row, studiosByName) {
    return (row.studioNames || [])
        .map(studioName => studiosByName.get(studioName.toLowerCase()))
        .filter(Boolean)
        .join('|');
}

function getCardShape(row, enableOverflow) {
    if (row.shape === 'portrait') return getPortraitShape(enableOverflow);
    if (row.shape === 'square') return getSquareShape(enableOverflow);

    return getBackdropShape(enableOverflow);
}

function getCardsHtml(row, items, options) {
    let html = cardBuilder.getCardsHtml({
        items,
        shape: getCardShape(row, options.enableOverflow),
        preferThumb: row.shape !== 'portrait',
        scalable: true,
        overlayPlayButton: true,
        allowBottomPadding: false,
        showTitle: true,
        showYear: row.shape !== 'square',
        centerText: true,
        context: 'home',
        lines: 2
    });

    if (row.moreUrl) {
        html += getMoreCardHtml(row, options);
    }

    return html;
}

function getRowItemsHtml(row, options) {
    return items => getCardsHtml(row, items, options);
}

function getRandomIndex(length) {
    if (length <= 1) return 0;

    backdropSeed = (backdropSeed * 1664525 + 1013904223) >>> 0;

    return backdropSeed % length;
}

function getDirectImageUrl(apiClient, itemId, type, options) {
    if (!apiClient?.getUrl || !itemId) return '';

    const path = typeof options.index === 'number' ?
        `Items/${itemId}/Images/${type}/${options.index}` :
        `Items/${itemId}/Images/${type}`;

    const params = {
        maxWidth: options.maxWidth
    };

    if (options.tag) {
        params.tag = options.tag;
    }

    return apiClient.getUrl(path, params);
}

function getImageUrl(apiClient, itemId, type, options) {
    if (!apiClient || !itemId) return '';

    return getDirectImageUrl(apiClient, itemId, type, options)
        || apiClient.getScaledImageUrl(itemId, {
            type,
            ...options
        });
}

function getBackdropUrl(apiClient, item) {
    if (!apiClient || !item?.Id) return '';

    if (item.BackdropImageTags?.length) {
        return getImageUrl(apiClient, item.Id, 'Backdrop', {
            maxWidth: 1280,
            index: 0,
            tag: item.BackdropImageTags[0]
        });
    }

    if (item.ParentBackdropItemId && item.ParentBackdropImageTags?.length) {
        return getImageUrl(apiClient, item.ParentBackdropItemId, 'Backdrop', {
            maxWidth: 1280,
            index: 0,
            tag: item.ParentBackdropImageTags[0]
        });
    }

    if (item.ImageTags?.Thumb) {
        return getImageUrl(apiClient, item.Id, 'Thumb', {
            maxWidth: 1280,
            tag: item.ImageTags.Thumb
        });
    }

    if (item.ParentThumbItemId && item.ParentThumbImageTag) {
        return getImageUrl(apiClient, item.ParentThumbItemId, 'Thumb', {
            maxWidth: 1280,
            tag: item.ParentThumbImageTag
        });
    }

    const primaryTag = item.ImageTags?.Primary
        || item.PrimaryImageTag
        || item.SeriesPrimaryImageTag
        || item.ParentPrimaryImageTag
        || item.AlbumPrimaryImageTag;

    if (!primaryTag) return '';

    return getImageUrl(apiClient, item.Id, 'Primary', {
        maxWidth: 900,
        tag: primaryTag
    });
}

function applyRowBackdrop(elem, apiClient, items) {
    const backdropElement = elem.querySelector('.ptv-row-backdrop');
    if (!backdropElement) return;

    const backdropItems = getUniqueItems(items)
        .map(item => ({
            item,
            url: getBackdropUrl(apiClient, item)
        }))
        .filter(entry => entry.url);

    if (!backdropItems.length) {
        elem.classList.remove('ptv-row-has-backdrop');
        backdropElement.removeAttribute('style');
        return;
    }

    const entry = backdropItems[getRandomIndex(backdropItems.length)];
    const safeUrl = entry.url.replace(/"/g, '%22');

    backdropElement.setAttribute('style', `background-image: url("${safeUrl}");`);
    elem.classList.add('ptv-row-has-backdrop');

    const homeSections = elem.closest('.homeSectionsContainer');
    if (homeSections && !homeSections.style.getPropertyValue('--ptv-home-backdrop-image')) {
        homeSections.style.setProperty('--ptv-home-backdrop-image', `url("${safeUrl}")`);
        homeSections.classList.add('ptv-home-has-backdrop');
    }
}

function forceLoadRowImages(itemsContainer) {
    window.requestAnimationFrame(() => {
        itemsContainer
            .querySelectorAll('.cardImageContainer.lazy[data-src], .cardFooterLogo.lazy[data-src]')
            .forEach((imageElement) => {
                imageLoader.lazyImage(imageElement);
            });
    });
}

function getMoreCardHtml(row, options) {
    const shape = getCardShape(row, options.enableOverflow);
    const url = escapeHtml(row.moreUrl);
    const title = escapeHtml(row.title);

    return [
        `<a is="emby-linkbutton" href="${url}" class="card ${shape}Card ptv-card ptv-row-more-card" aria-label="Open more ${title}">`,
        '<div class="cardBox">',
        '<div class="cardScalable">',
        `<div class="cardPadder cardPadder-${shape}"></div>`,
        '<div class="cardContent cardImageContainer coveredImage ptv-row-more-card-content">',
        '<span class="ptv-row-more-card-kicker">More</span>',
        `<span class="ptv-row-more-card-title">${title}</span>`,
        '<span class="material-icons chevron_right ptv-row-more-card-icon" aria-hidden="true"></span>',
        '</div>',
        '</div>',
        '</div>',
        '</a>'
    ].join('');
}

function getRowQuery(row, genreIds, studioIds = '') {
    const query = {
        Limit: ROW_ITEM_LIMIT,
        Recursive: true,
        Fields: MEDIA_FIELDS,
        EnableImages: true,
        ImageTypeLimit: 1,
        EnableImageTypes: 'Primary,Backdrop,Banner,Thumb',
        EnableTotalRecordCount: false
    };

    if (studioIds) {
        query.StudioIds = studioIds;
    }

    if (row.type === 'latest') {
        return {
            ...query,
            IncludeItemTypes: row.itemTypes,
            SortBy: 'PremiereDate,DateCreated,SortName',
            SortOrder: 'Descending'
        };
    }

    if (row.type === 'genre') {
        return {
            ...query,
            IncludeItemTypes: row.includeItemTypes || 'Movie,Series',
            GenreIds: genreIds,
            SortBy: 'Random'
        };
    }

    if (row.type === 'library') {
        const sortBy = row.sortBy || 'Random';

        return {
            ...query,
            IncludeItemTypes: row.itemTypes || 'Movie,Series',
            ParentId: row.parentId,
            SortBy: sortBy,
            SortOrder: sortBy === 'Random' ? undefined : row.sortOrder || 'Descending'
        };
    }

    return {
        ...query,
        IncludeItemTypes: row.includeItemTypes || 'Movie,Series',
        SearchTerm: row.searchTerm || row.searchTerms?.[0],
        SortBy: 'Random'
    };
}

function getLibraryParentId(row, userViews) {
    const libraryNames = row.libraryNames || [];
    const library = userViews.find(view =>
        view.Id
        && libraryNames.includes(`${view.Name || ''}`.toLowerCase())
    );

    return library?.Id || '';
}

function fetchRowResult(currentApiClient, userId, row, genresByName, studiosByName, userViews) {
    if (row.type === 'continue') {
        return currentApiClient.getResumableItems(userId, {
            Limit: ROW_ITEM_LIMIT,
            Recursive: true,
            Fields: MEDIA_FIELDS,
            EnableImages: true,
            ImageTypeLimit: 1,
            EnableImageTypes: 'Primary,Backdrop,Thumb',
            EnableTotalRecordCount: false,
            MediaTypes: 'Video'
        });
    }

    if (row.type === 'library') {
        const parentId = row.parentId || getLibraryParentId(row, userViews);

        if (!parentId) {
            return currentApiClient.getItems(userId, getRowQuery({
                ...row,
                type: 'search',
                searchTerm: row.title
            }, ''));
        }

        return currentApiClient.getItems(userId, getRowQuery({
            ...row,
            parentId
        }, ''));
    }

    const genreIds = row.type === 'genre' ? getGenreIds(row, genresByName) : '';
    const studioIds = getStudioIds(row, studiosByName);

    if (row.type === 'genre' && !genreIds) {
        return Promise.resolve({ Items: [] });
    }

    if (row.searchTerms?.length) {
        const searchRequests = row.searchTerms.map(searchTerm =>
            currentApiClient.getItems(userId, getRowQuery({
                ...row,
                searchTerm
            }, genreIds)).catch(() => ({ Items: [] }))
        );
        const studioRequests = studioIds ? [
            currentApiClient.getItems(userId, getRowQuery({
                ...row,
                searchTerm: undefined,
                searchTerms: undefined
            }, genreIds, studioIds))
                .catch(() => ({ Items: [] }))
        ] : [];

        return Promise.all([
            ...searchRequests,
            ...studioRequests
        ])
            .then(results => ({
                Items: getUniqueItems(getItemsFromResults(results))
                    .slice(0, ROW_ITEM_LIMIT)
            }));
    }

    return currentApiClient.getItems(userId, getRowQuery(row, genreIds, studioIds));
}

function getPayloadRowItems(payload, rowId) {
    const items = payload?.sectionItems?.[rowId];

    if (!Array.isArray(items) || !items.length) return null;
    if (!items.some(hasRenderableImage)) return null;

    return items;
}

function fetchSectionItems(currentApiClient, userId, row, lookupMaps, userViews) {
    if (row.type === 'libraries') {
        return Promise.resolve([
            row.id,
            userViews.slice(0, ROW_ITEM_LIMIT)
        ]);
    }

    const rowForQuery = row.type === 'library' ? {
        ...row,
        parentId: row.parentId || getLibraryParentId(row, userViews)
    } : row;

    return fetchRowResult(
        currentApiClient,
        userId,
        rowForQuery,
        lookupMaps.genresByName,
        lookupMaps.studiosByName,
        userViews
    )
        .then(result => [
            row.id,
            getItems(result).slice(0, ROW_ITEM_LIMIT)
        ]);
}

export function createFeaturedContentFetcher(apiClient, userId, rows, lookupMaps, userViews) {
    const serverId = apiClient.serverId();
    const contentRows = rows.filter(row => row.type !== 'libraries');

    return function () {
        const currentApiClient = ServerConnections.getApiClient(serverId);

        return Promise.all([
            loadHeroItems(currentApiClient, userId).catch(() => []),
            Promise.all(contentRows.map(row =>
                fetchSectionItems(currentApiClient, userId, row, lookupMaps, userViews)
            ))
                .then(entries => entries.reduce((sections, [sectionId, items]) => ({
                    ...sections,
                    [sectionId]: items
                }), {}))
        ])
            .then(([heroItems, sectionItems]) => ({
                heroItems,
                sectionItems
            }));
    };
}

function createFetchData(apiClient, userId, row, genresByName, studiosByName, userViews, featuredContentSource) {
    const serverId = apiClient.serverId();

    return function () {
        const currentApiClient = ServerConnections.getApiClient(serverId);
        const fetchFallbackRow = () => fetchRowResult(
            currentApiClient,
            userId,
            row,
            genresByName,
            studiosByName,
            userViews
        );
        const sharedFeaturedContent = featuredContentSource?.get?.()
            || getFeaturedContent(createFeaturedContentFetcher(
                apiClient,
                userId,
                [row],
                {
                    genresByName,
                    studiosByName
                },
                userViews
            ));

        return sharedFeaturedContent
            .then(payload => {
                const cachedItems = getPayloadRowItems(payload, row.id);

                if (cachedItems) {
                    return { Items: cachedItems };
                }

                return fetchFallbackRow();
            })
            .catch(fetchFallbackRow);
    };
}

function renderRowShell(elem, row, options) {
    let html = '';

    elem.classList.add('ptv-dynamic-row');
    html += '<div class="ptv-row-backdrop" aria-hidden="true"></div>';

    if (row.moreUrl) {
        html += `<a is="emby-linkbutton" href="${escapeHtml(row.moreUrl)}" class="sectionTitle sectionTitle-cards padded-left ptv-row-title-link" aria-label="Open ${escapeHtml(row.title)}">`;
        html += escapeHtml(row.title);
        html += '<span class="material-icons chevron_right ptv-row-title-link-icon" aria-hidden="true"></span>';
        html += '</a>';
    } else {
        html += '<h2 class="sectionTitle sectionTitle-cards padded-left">' + escapeHtml(row.title) + '</h2>';
    }

    if (options.enableOverflow) {
        html += '<div is="emby-scroller" class="padded-top-focusscale padded-bottom-focusscale" data-mousewheel="false" data-centerfocus="true">';
        html += '<div is="emby-itemscontainer" class="itemsContainer scrollSlider focuscontainer-x">';
    } else {
        html += '<div is="emby-itemscontainer" class="itemsContainer focuscontainer-x padded-left padded-right vertical-wrap">';
    }

    if (options.enableOverflow) {
        html += '</div>';
    }

    html += '</div>';
    elem.innerHTML = html;
}

export function renderLibraryRow(elem, apiClient, userViews, options) {
    const rowWithNavigation = {
        ...PTV_HOME_ROWS[0],
        moreUrl: `#/home.html?serverId=${encodeURIComponent(apiClient.serverId())}`
    };

    renderRowShell(elem, rowWithNavigation, options);

    const itemsContainer = elem.querySelector('.itemsContainer');
    if (!itemsContainer) return;

    let html = cardBuilder.getCardsHtml({
        items: userViews,
        shape: getBackdropShape(options.enableOverflow),
        showTitle: true,
        centerText: true,
        overlayText: false,
        lazy: true,
        transition: false,
        allowBottomPadding: !options.enableOverflow
    });

    html += getMoreCardHtml({
        ...rowWithNavigation,
        title: 'Libraries'
    }, options);

    itemsContainer.innerHTML = html;
    imageLoader.lazyChildren(elem);
    forceLoadRowImages(itemsContainer);
    applyRowBackdrop(elem, apiClient, userViews);
}

export function renderMediaRow(elem, apiClient, userId, row, lookupMaps, userViews, options) {
    const parentId = row.type === 'library' ? getLibraryParentId(row, userViews) : '';
    const rowWithNavigation = {
        ...row,
        parentId,
        moreUrl: getRowUrl({
            ...row,
            parentId
        }, lookupMaps.genresByName, apiClient.serverId())
    };

    renderRowShell(elem, rowWithNavigation, options);
    elem.classList.add('hide');

    const itemsContainer = elem.querySelector('.itemsContainer');
    if (!itemsContainer) return;

    itemsContainer.fetchData = createFetchData(
        apiClient,
        userId,
        rowWithNavigation,
        lookupMaps.genresByName,
        lookupMaps.studiosByName,
        userViews,
        options.featuredContentSource
    );
    itemsContainer.getItemsHtml = getRowItemsHtml(rowWithNavigation, options);
    itemsContainer.parentContainer = elem;
    itemsContainer.afterRefresh = function (result) {
        applyRowBackdrop(elem, apiClient, getItems(result));
        forceLoadRowImages(itemsContainer);
    };
}

export function loadGenreMap(apiClient, userId) {
    return apiClient.getGenres(userId, {
        SortBy: 'SortName',
        SortOrder: 'Ascending',
        IncludeItemTypes: 'Movie,Series',
        Recursive: true,
        Limit: 300
    })
        .then(result => new Map((result.Items || [])
            .filter(genre => genre.Id && genre.Name)
            .map(genre => [genre.Name.toLowerCase(), genre.Id])))
        .catch(() => new Map());
}

export function loadStudioMap(apiClient, userId) {
    if (!apiClient.getStudios) {
        return Promise.resolve(new Map());
    }

    return apiClient.getStudios(userId, {
        SortBy: 'SortName',
        SortOrder: 'Ascending',
        IncludeItemTypes: 'Movie,Series',
        Recursive: true,
        Limit: 500
    })
        .then(result => new Map((result.Items || [])
            .filter(studio => studio.Id && studio.Name)
            .map(studio => [studio.Name.toLowerCase(), studio.Id])))
        .catch(() => new Map());
}
