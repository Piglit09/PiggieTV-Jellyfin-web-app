import { PTV_CACHE, PTV_EVENTS } from '../../core/config';
import { dispatchPtvCustomEvent } from '../../core/events';

export const FEATURED_CACHE_VERSION = PTV_CACHE.featuredContentVersion;
export const FEATURED_CACHE_UPDATED_EVENT = PTV_EVENTS.featuredCacheUpdated;

const FEATURED_CACHE_KEY = PTV_CACHE.featuredContentKey;
const FEATURED_CACHE_TTL_MS = PTV_CACHE.featuredContentTtlMs;

export type FeaturedPayload = {
    heroItems: unknown[];
    sectionItems: Record<string, unknown[]>;
};

type FeaturedCacheEntry = {
    version: typeof FEATURED_CACHE_VERSION;
    createdAt: number;
    expiresAt: number;
    payload: FeaturedPayload;
};

type DebugWindow = Window & Partial<Record<'PTV_DEBUG', boolean>>;

let inflightFeaturedContent: Promise<FeaturedPayload> | null = null;

function debugLog(message: string, detail?: unknown) {
    if (typeof window !== 'undefined' && (window as DebugWindow)['PTV_DEBUG'] === true) {
        console.debug(`[PTV Featured Cache] ${message}`, detail);
    }
}

function getStorage() {
    if (typeof window === 'undefined') return null;

    try {
        return window.localStorage;
    } catch {
        return null;
    }
}

function isRecord(value: unknown): value is Record<string, unknown> {
    return Boolean(value) && typeof value === 'object' && !Array.isArray(value);
}

function normalizeSectionItems(value: unknown): Record<string, unknown[]> {
    if (!isRecord(value)) return {};

    return Object.keys(value).reduce<Record<string, unknown[]>>((sections, sectionId) => {
        const items = value[sectionId];

        if (Array.isArray(items)) {
            sections[sectionId] = items;
        }

        return sections;
    }, {});
}

function normalizePayload(payload: FeaturedPayload): FeaturedPayload {
    return {
        heroItems: Array.isArray(payload.heroItems) ? payload.heroItems : [],
        sectionItems: normalizeSectionItems(payload.sectionItems)
    };
}

function mergePayload(payload: FeaturedPayload, fallbackPayload?: FeaturedPayload): FeaturedPayload {
    const normalizedPayload = normalizePayload(payload);

    if (!fallbackPayload) return normalizedPayload;

    const normalizedFallbackPayload = normalizePayload(fallbackPayload);
    const sectionItems = {
        ...normalizedFallbackPayload.sectionItems
    };

    Object.keys(normalizedPayload.sectionItems).forEach(sectionId => {
        const items = normalizedPayload.sectionItems[sectionId];

        if (items.length || !sectionItems[sectionId]) {
            sectionItems[sectionId] = items;
        }
    });

    return {
        heroItems: normalizedPayload.heroItems.length ?
            normalizedPayload.heroItems :
            normalizedFallbackPayload.heroItems,
        sectionItems
    };
}

function parseCacheEntry(rawCache: string | null): FeaturedCacheEntry | null {
    if (!rawCache) return null;

    try {
        const parsed = JSON.parse(rawCache) as unknown;

        if (!isRecord(parsed)) return null;
        if (parsed.version !== FEATURED_CACHE_VERSION) return null;
        if (typeof parsed.createdAt !== 'number') return null;
        if (typeof parsed.expiresAt !== 'number') return null;
        if (!isRecord(parsed.payload)) return null;

        return {
            version: FEATURED_CACHE_VERSION,
            createdAt: parsed.createdAt,
            expiresAt: parsed.expiresAt,
            payload: normalizePayload(parsed.payload as FeaturedPayload)
        };
    } catch {
        return null;
    }
}

function readCacheEntry() {
    const storage = getStorage();
    if (!storage) return null;

    const entry = parseCacheEntry(storage.getItem(FEATURED_CACHE_KEY));

    if (!entry) {
        storage.removeItem(FEATURED_CACHE_KEY);
    }

    return entry;
}

function writeCacheEntry(payload: FeaturedPayload) {
    const storage = getStorage();
    if (!storage) return;

    const createdAt = Date.now();
    const entry: FeaturedCacheEntry = {
        version: FEATURED_CACHE_VERSION,
        createdAt,
        expiresAt: createdAt + FEATURED_CACHE_TTL_MS,
        payload: normalizePayload(payload)
    };

    try {
        storage.setItem(FEATURED_CACHE_KEY, JSON.stringify(entry));
        debugLog('stored fresh payload', {
            heroItems: entry.payload.heroItems.length,
            sections: Object.keys(entry.payload.sectionItems).length,
            expiresAt: entry.expiresAt
        });
    } catch (err) {
        debugLog('failed to store payload', err);
    }
}

function dispatchCacheUpdated() {
    if (typeof window === 'undefined') return;

    dispatchPtvCustomEvent(FEATURED_CACHE_UPDATED_EVENT);
}

function refreshFeaturedContent(
    fetcher: () => Promise<FeaturedPayload>,
    fallbackPayload?: FeaturedPayload,
    notifyOnSuccess = false
) {
    inflightFeaturedContent = fetcher()
        .then(payload => {
            const normalizedPayload = mergePayload(payload, fallbackPayload);
            writeCacheEntry(normalizedPayload);

            if (notifyOnSuccess) {
                dispatchCacheUpdated();
            }

            return normalizedPayload;
        })
        .catch((err: unknown) => {
            if (fallbackPayload) {
                debugLog('refresh failed, keeping stale payload', err);

                return fallbackPayload;
            }

            throw err;
        })
        .finally(() => {
            inflightFeaturedContent = null;
        });

    return inflightFeaturedContent;
}

export function isFeaturedContentCacheFresh() {
    const cached = readCacheEntry();

    return Boolean(cached && Date.now() < cached.expiresAt);
}

export function clearFeaturedContentCache() {
    inflightFeaturedContent = null;

    const storage = getStorage();
    if (!storage) return;

    storage.removeItem(FEATURED_CACHE_KEY);
    debugLog('cleared');
}

export function getFeaturedContent(fetcher: () => Promise<FeaturedPayload>): Promise<FeaturedPayload> {
    const cached = readCacheEntry();

    if (cached && Date.now() < cached.expiresAt) {
        debugLog('fresh hit', {
            heroItems: cached.payload.heroItems.length,
            sections: Object.keys(cached.payload.sectionItems).length
        });

        return Promise.resolve(cached.payload);
    }

    if (cached) {
        debugLog('stale hit, refreshing in background', {
            heroItems: cached.payload.heroItems.length,
            sections: Object.keys(cached.payload.sectionItems).length
        });

        if (!inflightFeaturedContent) {
            void refreshFeaturedContent(fetcher, cached.payload, true);
        }

        return Promise.resolve(cached.payload);
    }

    if (inflightFeaturedContent) {
        debugLog('reusing in-flight request');

        return inflightFeaturedContent;
    }

    return refreshFeaturedContent(fetcher);
}
