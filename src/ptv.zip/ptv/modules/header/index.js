import { watchDom } from '../../core/observer';
import { PTV_ASSETS, PTV_BRANDING, PTV_EVENTS, PTV_ROUTES } from '../../core/config';
import { dispatchPtvCustomEvent } from '../../core/events';
import { registerModule } from '../../core/lifecycle';
import { create } from '../../utils/dom';
import { createIcon, iconNameFromText, runIconEngine } from '../../utils/icons';
import { startPtvIconEngine } from '../icons';

const REQUEST_ROUTE = PTV_ROUTES.requestSafe;
const HEADER_SELECTOR = '.ptv-skinHeader, .skinHeader';
const HEADER_ICON_TARGET_SELECTOR = [
    '.ptv-skinHeader button',
    '.skinHeader button',
    '.ptv-skinHeader .paper-icon-button-light',
    '.skinHeader .paper-icon-button-light'
].join(', ');
const HEADER_REPAIR_DELAYS = [0, 100, 300, 750, 1500];
const HEADER_ICON_CLASS_MAP = [
    ['headerBackButton', 'back'],
    ['headerHomeButton', 'home'],
    ['mainDrawerButton', 'menu'],
    ['barsMenuButton', 'menu'],
    ['headerSyncButton', 'users'],
    ['syncButton', 'users'],
    ['headerAudioPlayerButton', 'music'],
    ['audioPlayerButton', 'music'],
    ['headerCastButton', 'cast'],
    ['castButton', 'cast'],
    ['headerSearchButton', 'search'],
    ['headerUserButton', 'user']
];
const PTV_LOGO_URL = PTV_ASSETS.logos.bannerLight;

let headerRepairPending = false;
const watchedHeaders = new WeakMap();

function isHomeRoute() {
    const hash = window.location.hash || '';

    return hash === PTV_ROUTES.home
        || hash === PTV_ROUTES.homeHtml
        || hash.startsWith(`${PTV_ROUTES.home}?`)
        || hash.startsWith(`${PTV_ROUTES.homeHtml}?`);
}

function isRequestRoute() {
    return document.documentElement.classList.contains('ptv-request-active');
}

function isHomeTabsRoute() {
    return isHomeRoute() || isRequestRoute();
}

function getActiveTopTab() {
    const hash = window.location.hash || '';

    if (isRequestRoute()) return 'request';
    if (hash.startsWith(PTV_ROUTES.favoritesLegacy) || hash.includes('tab=1')) return 'favorites';

    return 'home';
}

function openRequestTab(event) {
    event.preventDefault();
    event.stopPropagation();
    event.stopImmediatePropagation?.();
    window.PTV?.openRequestPortal?.();
    dispatchPtvCustomEvent(PTV_EVENTS.requestOpen);
}

function getTabLabel(tab) {
    return (tab.textContent || '').trim().toLowerCase();
}

function bindHomeTabs(tabsContainer) {
    const activeTab = getActiveTopTab();

    tabsContainer.querySelectorAll('.tabs-viewmenubar').forEach((tabBar) => {
        tabBar.classList.add('ptv-top-tabs');
    });

    tabsContainer.querySelectorAll('.emby-tabs-slider').forEach((slider) => {
        slider.classList.add('ptv-top-tabs-slider');
    });

    tabsContainer.querySelectorAll('.emby-tab-button').forEach((tab) => {
        const label = getTabLabel(tab);

        tab.classList.add('ptv-top-tab');
        tab.classList.remove('emby-tab-button-active');
        tab.removeAttribute('aria-current');
        tab.setAttribute('aria-selected', 'false');

        if (label === 'home') {
            tab.classList.add('ptv-top-tab-home');
            tab.classList.toggle('emby-tab-button-active', activeTab === 'home');
            tab.setAttribute('aria-selected', String(activeTab === 'home'));
            return;
        }

        if (label === 'favorites') {
            tab.classList.add('ptv-top-tab-favorites');
            tab.classList.toggle('emby-tab-button-active', activeTab === 'favorites');
            tab.setAttribute('aria-selected', String(activeTab === 'favorites'));
            return;
        }

        if (label !== 'request') return;

        tab.classList.add('ptv-top-tab-request');
        tab.classList.toggle('emby-tab-button-active', activeTab === 'request');
        tab.setAttribute('aria-selected', String(activeTab === 'request'));
        tab.setAttribute('href', REQUEST_ROUTE);
        tab.setAttribute('data-ptv-request-trigger', 'true');
        tab.removeAttribute('target');
        tab.removeAttribute('rel');
        tab.removeAttribute('data-ptv-external');
        tab.removeAttribute('is');

        if (tab.dataset.ptvRequestBound === 'true') return;

        tab.dataset.ptvRequestBound = 'true';
        tab.addEventListener('click', openRequestTab, { capture: true });
    });
}

function ensureHomeTabs(header) {
    const tabsContainer = header?.querySelector('.headerTabs');

    if (!tabsContainer) return;

    if (!isHomeTabsRoute()) {
        const fallbackTabs = tabsContainer.querySelector('.ptv-home-tabs');

        if (fallbackTabs) {
            tabsContainer.innerHTML = '';
            tabsContainer.classList.add('hide');
        }

        return;
    }

    const hasUsableTabs = tabsContainer.querySelector('.tabs-viewmenubar .emby-tab-button');
    const hasRequestTab = tabsContainer.textContent?.includes('Request');

    if (hasUsableTabs && hasRequestTab) {
        tabsContainer.classList.remove('hide');
        bindHomeTabs(tabsContainer);
        return;
    }

    const activeTab = getActiveTopTab();

    tabsContainer.innerHTML = `
        <div is="emby-tabs" class="tabs-viewmenubar ptv-home-tabs ptv-top-tabs">
            <div class="emby-tabs-slider ptv-top-tabs-slider" style="white-space:nowrap;">
                <a href="${PTV_ROUTES.home}" is="emby-linkbutton" class="emby-tab-button ${activeTab === 'home' ? 'emby-tab-button-active' : ''} ptv-top-tab ptv-top-tab-home" data-index="0" aria-selected="${activeTab === 'home'}">
                    <div class="emby-button-foreground">Home</div>
                </a>
                <a href="${PTV_ROUTES.favorites}" is="emby-linkbutton" class="emby-tab-button ${activeTab === 'favorites' ? 'emby-tab-button-active' : ''} ptv-top-tab ptv-top-tab-favorites" data-index="1" aria-selected="${activeTab === 'favorites'}">
                    <div class="emby-button-foreground">Favorites</div>
                </a>
                <a href="${REQUEST_ROUTE}" class="emby-tab-button ${activeTab === 'request' ? 'emby-tab-button-active' : ''} ptv-top-tab ptv-top-tab-request" data-index="2" data-ptv-request-trigger="true" aria-selected="${activeTab === 'request'}">
                    <div class="emby-button-foreground">Request</div>
                </a>
            </div>
        </div>
    `;
    tabsContainer.classList.remove('hide');
    bindHomeTabs(tabsContainer);
    document.body.classList.add('withSectionTabs');

    window.CustomElements?.upgradeSubtree?.(tabsContainer);
}

function normalizeSidebarLogo(logo, brandType) {
    if (!(logo instanceof HTMLImageElement)) return;

    logo.src = PTV_LOGO_URL;
    logo.alt = PTV_BRANDING.appName;
    logo.loading = 'eager';
    logo.decoding = 'async';
    logo.draggable = false;
    logo.dataset.ptvLogo = brandType;

    if (brandType === 'sidebar') {
        logo.className = 'ptv-sidebar-logo ptv-sidebar-logo-image ptv-drawer-logo';
        logo.width = 226;
        logo.height = 58;
        return;
    }

    logo.className = 'ptv-drawer-logo';
    logo.width = 172;
    logo.height = 48;
}

function cleanupBrandLogos(brand, brandType) {
    const logoSelector = brandType === 'sidebar' ?
        '[data-ptv-logo="sidebar"], .ptv-sidebar-logo, :scope > img[src*="assets/logo/"]' :
        '[data-ptv-logo="drawer"], .ptv-drawer-logo, :scope > img[src*="assets/logo/"]';
    const logos = Array.from(brand.querySelectorAll(logoSelector));
    const [logo, ...extraLogos] = logos;

    extraLogos.forEach(extraLogo => {
        extraLogo.remove();
    });

    if (logo instanceof HTMLImageElement) {
        normalizeSidebarLogo(logo, brandType);
    }
}

function cleanupSidebarBranding() {
    document.querySelectorAll('.ptv-sidebar').forEach((sidebar) => {
        const brands = Array.from(sidebar.querySelectorAll(':scope > [data-ptv-brand="sidebar"], :scope > .ptv-sidebar-brand'));
        const [brand, ...extraBrands] = brands;

        extraBrands.forEach(extraBrand => {
            extraBrand.remove();
        });

        if (brand instanceof HTMLElement) {
            brand.dataset.ptvBrand = 'sidebar';
            brand.classList.add('ptv-sidebar-brand');
            cleanupBrandLogos(brand, 'sidebar');
        }

        sidebar.querySelectorAll(':scope > img[src*="assets/logo/"]').forEach(logo => {
            logo.remove();
        });
    });

    document.querySelectorAll('.ptv-mainDrawer, .mainDrawer').forEach((drawer) => {
        const brands = Array.from(drawer.querySelectorAll(':scope .ptv-main-drawer-brand'));
        const [brand, ...extraBrands] = brands;

        extraBrands.forEach(extraBrand => {
            extraBrand.remove();
        });

        if (brand instanceof HTMLElement) {
            brand.dataset.ptvBrand = 'drawer';
            cleanupBrandLogos(brand, 'drawer');
        }
    });
}

function isAvatarHeaderButton(button) {
    return button.classList.contains('headerUserButtonRound')
        || Boolean(button.querySelector('.headerUserButtonRound'))
        || Boolean(button.getAttribute('style')?.includes('background-image'));
}

function getHeaderIconKey(button) {
    const existingIcon = button.querySelector('.ptv-icon[data-ptv-icon]');
    const existingIconName = existingIcon?.getAttribute('data-ptv-icon');

    if (existingIconName) return existingIconName;

    for (const [className, iconName] of HEADER_ICON_CLASS_MAP) {
        if (button.classList.contains(className)) return iconName;
    }

    const legacyIcon = button.querySelector('.material-icons, .material-icons-round, .material-icons-outlined');
    const text = [
        legacyIcon?.textContent,
        legacyIcon ? Array.from(legacyIcon.classList).join(' ') : '',
        button.getAttribute('title'),
        button.getAttribute('aria-label'),
        Array.from(button.classList).join(' ')
    ].filter(Boolean).join(' ');

    return iconNameFromText(text);
}

function cleanupHeaderButtonIcons(button) {
    const icons = Array.from(button.querySelectorAll(':scope > .ptv-icon'));
    const [firstIcon, ...extraIcons] = icons;

    extraIcons.forEach(icon => {
        icon.remove();
    });

    return firstIcon;
}

function mountHeaderIcon(button, iconName) {
    if (!iconName || isAvatarHeaderButton(button)) return;

    runIconEngine(button);

    const existingIcon = cleanupHeaderButtonIcons(button) || button.querySelector('.ptv-icon');
    if (existingIcon) {
        existingIcon.setAttribute('data-ptv-icon', iconName);
        existingIcon.setAttribute('data-icon', iconName);
        existingIcon.setAttribute('aria-hidden', 'true');
        existingIcon.classList.add('ptv-header-mounted-icon');
        return;
    }

    const icon = createIcon(iconName, 'ptv-icon ptv-header-mounted-icon');
    button.prepend(icon);
}

function repairHeaderIcons() {
    document
        .querySelectorAll(HEADER_ICON_TARGET_SELECTOR)
        .forEach(button => {
            if (isAvatarHeaderButton(button)) {
                button.dataset.ptvHeaderIconReady = 'avatar';
                return;
            }

            const iconName = getHeaderIconKey(button);
            if (!iconName) return;

            const hasIcon = Boolean(button.querySelector('.ptv-icon'));

            if (!hasIcon) {
                mountHeaderIcon(button, iconName);
            } else {
                cleanupHeaderButtonIcons(button);
            }

            button.dataset.ptvHeaderIconReady = 'true';
        });
}

function scheduleHeaderRepair() {
    if (headerRepairPending) return;

    headerRepairPending = true;

    HEADER_REPAIR_DELAYS.forEach((delay, index) => {
        window.setTimeout(() => {
            repairHeaderIcons();

            if (index === HEADER_REPAIR_DELAYS.length - 1) {
                headerRepairPending = false;
            }
        }, delay);
    });
}

function watchHeaderContainers() {
    document.querySelectorAll(HEADER_SELECTOR).forEach(header => {
        if (watchedHeaders.has(header)) return;

        const observer = new MutationObserver(scheduleHeaderRepair);
        observer.observe(header, {
            childList: true,
            subtree: true
        });

        watchedHeaders.set(header, observer);
    });
}

function patchHeaderHistoryEvents() {
    if (window.__ptvHeaderHistoryPatched) return;

    window.__ptvHeaderHistoryPatched = true;

    const originalPushState = window.history.pushState;
    const originalReplaceState = window.history.replaceState;

    window.history.pushState = function (...args) {
        const result = originalPushState.apply(this, args);
        scheduleHeaderRepair();
        return result;
    };

    window.history.replaceState = function (...args) {
        const result = originalReplaceState.apply(this, args);
        scheduleHeaderRepair();
        return result;
    };
}

function enhanceHeaderIcons() {
    const header = document.querySelector('.ptv-legacy-skinHeader, .skinHeader');
    const headerLeft = header?.querySelector('.headerLeft');

    cleanupSidebarBranding();

    if (headerLeft) {
        const logos = Array.from(headerLeft.querySelectorAll('.ptv-header-logo'));
        const [logo, ...extraLogos] = logos;
        extraLogos.forEach((extraLogo) => {
            extraLogo.remove();
        });

        if (!logo) {
            const headerLogo = create('a', {
                className: 'ptv-header-logo itemAction',
                attrs: {
                    href: PTV_ROUTES.home,
                    'data-action': 'link',
                    'aria-label': 'Go to home'
                }
            });

            headerLogo.appendChild(create('img', {
                attrs: {
                    src: PTV_LOGO_URL,
                    alt: PTV_BRANDING.appName,
                    loading: 'eager',
                    decoding: 'async'
                }
            }));
            headerLeft.appendChild(headerLogo);
        } else {
            logo.setAttribute('class', 'ptv-header-logo itemAction');
            logo.setAttribute('href', PTV_ROUTES.home);
            logo.setAttribute('data-action', 'link');
            logo.setAttribute('aria-label', 'Go to home');
        }

        headerLeft.querySelectorAll('.ptv-stock-header-logo').forEach((extraLogo) => {
            extraLogo.remove();
        });
        headerLeft.querySelectorAll('.ptv-header-logo img + img').forEach((extraLogo) => {
            extraLogo.remove();
        });
    }

    if (!header) return;

    ensureHomeTabs(header);

    header
        .querySelectorAll('button, .headerButton')
        .forEach(button => {
            button.classList.add('ptv-header-stock-button');
        });

    runIconEngine(header);
    repairHeaderIcons();
    watchHeaderContainers();
}

watchDom(() => {
    enhanceHeaderIcons();
    cleanupSidebarBranding();
    scheduleHeaderRepair();
    watchHeaderContainers();
});

[
    ['hashchange', window],
    ['popstate', window],
    [PTV_EVENTS.requestStateChange, window],
    ['pageshow', window],
    ['viewshow', document],
    ['viewhide', document],
    ['pagebeforeshow', document]
].forEach(([eventName, target]) => {
    target.addEventListener(eventName, () => {
        cleanupSidebarBranding();
        enhanceHeaderIcons();
        scheduleHeaderRepair();
    });
});

patchHeaderHistoryEvents();
registerModule({
    density: 'comfortable',
    features: ['header', 'navigation', 'shell'],
    name: 'header',
    surface: 2,
    widgets: [
        {
            density: 'comfortable',
            id: 'shell-header',
            surface: 2,
            type: 'navigation'
        }
    ]
});

startPtvIconEngine();
enhanceHeaderIcons();
scheduleHeaderRepair();
