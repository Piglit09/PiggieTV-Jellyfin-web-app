import { useEffect, useState } from 'react';

import {
    FEATURED_CACHE_UPDATED_EVENT,
    getFeaturedContent,
    type FeaturedPayload
} from '../cache/featuredContentCache';
import type { HeroApiClient, HeroItem } from './useHeroItem';

type SeasonalRecommendationContext = {
    label: string;
    searchTerms: string[];
};

const HERO_ITEM_LIMIT = 20;
const HERO_BUCKET_LIMIT = 5;
const HERO_BUCKET_QUERY_LIMIT = 36;
const SEASONAL_LOOKUP_TIMEOUT_MS = 2200;
const TRENDING_LOOKUP_TIMEOUT_MS = 2500;

const HERO_FIELDS = 'Overview,Genres,PrimaryImageAspectRatio,ParentId,CommunityRating,CriticRating,OfficialRating,RunTimeTicks,PremiereDate';

type HeroLibraryBucket = {
    itemTypes: string;
    label: string;
};

const HERO_LIBRARY_BUCKETS: HeroLibraryBucket[] = [
    {
        itemTypes: 'Movie',
        label: 'Trending Movies'
    },
    {
        itemTypes: 'Series',
        label: 'Trending Shows'
    },
    {
        itemTypes: 'Episode',
        label: 'Trending Episodes'
    },
    {
        itemTypes: 'MusicAlbum',
        label: 'Trending Music'
    }
];

const SEASONAL_RECOMMENDATIONS: Array<SeasonalRecommendationContext & {
    start: [number, number];
    end: [number, number];
}> = [
    {
        label: 'Halloween Picks',
        start: [10, 1],
        end: [10, 31],
        searchTerms: ['Halloween', 'haunted', 'ghost', 'witch', 'monster']
    },
    {
        label: 'Thanksgiving Picks',
        start: [11, 15],
        end: [11, 30],
        searchTerms: ['Thanksgiving', 'family', 'homecoming', 'feast']
    },
    {
        label: 'Holiday Picks',
        start: [12, 1],
        end: [12, 31],
        searchTerms: ['Christmas', 'holiday', 'snow', 'winter', 'Santa']
    },
    {
        label: 'New Year Picks',
        start: [1, 1],
        end: [1, 7],
        searchTerms: ['New Year', 'party', 'celebration']
    },
    {
        label: 'Valentine Picks',
        start: [2, 1],
        end: [2, 14],
        searchTerms: ['Valentine', 'romance', 'love', 'wedding']
    },
    {
        label: 'Spring Picks',
        start: [3, 1],
        end: [5, 31],
        searchTerms: ['spring', 'adventure', 'nature', 'garden']
    },
    {
        label: 'Summer Picks',
        start: [6, 1],
        end: [8, 31],
        searchTerms: ['summer', 'beach', 'vacation', 'camp']
    },
    {
        label: 'Fall Picks',
        start: [9, 1],
        end: [11, 14],
        searchTerms: ['fall', 'autumn', 'school', 'football']
    },
    {
        label: 'Winter Picks',
        start: [1, 8],
        end: [2, 29],
        searchTerms: ['winter', 'snow', 'mountain', 'ice']
    }
];

function getDateKey(month: number, day: number) {
    return (month * 100) + day;
}

function isDateInRange(dateKey: number, start: [number, number], end: [number, number]) {
    const startKey = getDateKey(start[0], start[1]);
    const endKey = getDateKey(end[0], end[1]);

    if (startKey <= endKey) {
        return dateKey >= startKey && dateKey <= endKey;
    }

    return dateKey >= startKey || dateKey <= endKey;
}

function getSeasonalRecommendationContext(date = new Date()): SeasonalRecommendationContext | null {
    const dateKey = getDateKey(date.getMonth() + 1, date.getDate());

    return SEASONAL_RECOMMENDATIONS.find(recommendation =>
        isDateInRange(dateKey, recommendation.start, recommendation.end)
    ) || null;
}

function getDailyIndex(length: number) {
    if (length <= 1) return 0;

    return Math.floor(Date.now() / 86400000) % length;
}

function withTimeout<T>(promise: Promise<T>, timeoutMs: number, fallback: T) {
    return new Promise<T>(resolve => {
        const timeout = window.setTimeout(() => resolve(fallback), timeoutMs);

        promise
            .then(resolve)
            .catch(() => resolve(fallback))
            .finally(() => window.clearTimeout(timeout));
    });
}

function hasHeroImages(item: HeroItem) {
    return Boolean(item.Id) && (
        Boolean(item.BackdropImageTags?.length)
        || Boolean(item.BackdropImageTag)
        || Boolean(item.BackdropItemId)
        || Boolean(item.ParentBackdropItemId && item.ParentBackdropImageTags?.length)
        || Boolean(item.ParentBackdropItemId && item.ParentBackdropImageTag)
        || Boolean(item.ImageTags?.Primary)
        || Boolean(item.PrimaryImageTag)
    );
}

function getItemTrendScore(item: HeroItem) {
    const criticRating = item.CriticRating || 0;
    const communityRating = item.CommunityRating ? item.CommunityRating * 10 : 0;
    const releaseYear = item.ProductionYear || (
        item.PremiereDate ? new Date(item.PremiereDate).getFullYear() : 0
    );
    const recencyBoost = releaseYear ?
        Math.max(0, Math.min(12, releaseYear - 2014)) :
        0;

    return (criticRating * 0.55) + (communityRating * 0.45) + recencyBoost;
}

function sortByTrending(items: HeroItem[]) {
    return [...items].sort((a, b) => getItemTrendScore(b) - getItemTrendScore(a));
}

function interleaveBuckets(buckets: HeroItem[][], limit = HERO_ITEM_LIMIT) {
    const results: HeroItem[] = [];
    const usedIds = new Set<string>();
    const maxBucketLength = Math.max(...buckets.map(bucket => bucket.length), 0);

    for (let index = 0; index < maxBucketLength && results.length < limit; index++) {
        for (const bucket of buckets) {
            const item = bucket[index];

            if (!item?.Id || usedIds.has(item.Id)) continue;

            usedIds.add(item.Id);
            results.push(item);

            if (results.length >= limit) break;
        }
    }

    return results;
}

function hydrateHeroItems(
    apiClient: HeroApiClient,
    userId: string,
    items: HeroItem[]
) {
    const itemsWithId = items.filter((item): item is HeroItem & { Id: string } => Boolean(item.Id));

    if (!apiClient.getItem) {
        return Promise.resolve(itemsWithId);
    }

    const getItem = apiClient.getItem.bind(apiClient);

    return Promise.all(itemsWithId.map(item =>
        getItem(userId, item.Id)
            .then(fullItem => ({
                ...item,
                ...fullItem,
                ImageTags: {
                    ...item.ImageTags,
                    ...fullItem.ImageTags
                }
            }))
            .catch(() => item)
    ));
}

function getResumableHeroItems(apiClient: HeroApiClient, userId: string) {
    if (!apiClient.getResumableItems) {
        return Promise.resolve({ Items: [] });
    }

    return apiClient.getResumableItems(userId, {
        Limit: HERO_ITEM_LIMIT,
        Recursive: true,
        Fields: HERO_FIELDS,
        ImageTypeLimit: 1,
        EnableImageTypes: 'Primary,Backdrop,Logo',
        EnableTotalRecordCount: false,
        IncludeItemTypes: 'Movie,Episode',
        MediaTypes: 'Video'
    });
}

function getTrendingHeroItems(apiClient: HeroApiClient, userId: string) {
    if (!apiClient.getItems) {
        return Promise.resolve([]);
    }

    const getItems = apiClient.getItems.bind(apiClient);
    const bucketLookups = HERO_LIBRARY_BUCKETS.map(bucket =>
        getItems(userId, {
            Limit: HERO_BUCKET_QUERY_LIMIT,
            Recursive: true,
            Fields: HERO_FIELDS,
            ImageTypeLimit: 1,
            EnableImageTypes: 'Primary,Backdrop,Logo',
            EnableTotalRecordCount: false,
            IncludeItemTypes: bucket.itemTypes,
            SortBy: 'CommunityRating,CriticRating,DateCreated',
            SortOrder: 'Descending'
        })
            .then(result => getCinematicItems(
                apiClient,
                userId,
                sortByTrending(result.Items || []),
                'featured',
                bucket.label,
                HERO_BUCKET_LIMIT,
                false
            ))
            .catch(() => [])
    );

    return withTimeout(
        Promise.all(bucketLookups)
            .then(buckets => interleaveBuckets(buckets, HERO_ITEM_LIMIT)),
        TRENDING_LOOKUP_TIMEOUT_MS,
        []
    );
}

function getCinematicItems(
    apiClient: HeroApiClient,
    userId: string,
    items: HeroItem[],
    source: NonNullable<HeroItem['PtvHeroSource']>,
    recommendationLabel?: string,
    itemLimit = HERO_ITEM_LIMIT,
    hydrateItems = true
) {
    const candidateItems = items.filter(item => Boolean(item.Id)).slice(0, itemLimit);
    const itemPromise = hydrateItems ?
        hydrateHeroItems(apiClient, userId, candidateItems) :
        Promise.resolve(candidateItems);

    return itemPromise
        .then(hydratedItems => hydratedItems
            .filter(hasHeroImages)
            .map(item => ({
                ...item,
                PtvHeroSource: source,
                PtvHeroRecommendationLabel: recommendationLabel
            }))
            .slice(0, itemLimit));
}

function getUniqueHeroItems(items: HeroItem[]) {
    const usedIds = new Set<string>();

    return items.filter(item => {
        if (!item.Id || usedIds.has(item.Id)) return false;

        usedIds.add(item.Id);
        return true;
    });
}

function getResultItems(results: Array<{ Items?: HeroItem[] }>) {
    const items: HeroItem[] = [];

    results.forEach(result => {
        items.push(...(result.Items || []));
    });

    return items;
}

function balanceHeroItems(items: HeroItem[]) {
    const uniqueItems = getUniqueHeroItems(items);
    const featuredItems = uniqueItems.filter(item => item.PtvHeroSource !== 'continue');
    const continueItems = uniqueItems.filter(item => item.PtvHeroSource === 'continue');

    return interleaveBuckets([featuredItems, continueItems], HERO_ITEM_LIMIT);
}

function toHeroItems(items: unknown[]) {
    return items.filter((item): item is HeroItem => Boolean(item) && typeof item === 'object');
}

function getSeasonalHeroItems(apiClient: HeroApiClient, userId: string) {
    if (!apiClient.getItems) {
        return Promise.resolve([]);
    }

    const getItems = apiClient.getItems.bind(apiClient);
    const seasonalContext = getSeasonalRecommendationContext();

    if (!seasonalContext) {
        return Promise.resolve([]);
    }

    const seasonalLookup = Promise.resolve()
        .then(() => Promise.all(seasonalContext.searchTerms.map(searchTerm =>
            getItems(userId, {
                Limit: HERO_BUCKET_QUERY_LIMIT,
                Recursive: true,
                Fields: HERO_FIELDS,
                ImageTypeLimit: 1,
                EnableImageTypes: 'Primary,Backdrop,Logo',
                EnableTotalRecordCount: false,
                IncludeItemTypes: 'Movie,Episode',
                SortBy: 'CommunityRating,CriticRating,DateCreated',
                SortOrder: 'Descending',
                SearchTerm: searchTerm
            }).catch(() => ({ Items: [] }))
        )))
        .then(results => getUniqueHeroItems(getResultItems(results)))
        .then(items => {
            const seasonalBucket = sortByTrending(items).slice(0, HERO_ITEM_LIMIT);
            const seasonalMovieItems = seasonalBucket.filter(item => item.Type === 'Movie');
            const seasonalEpisodeItems = seasonalBucket.filter(item => item.Type === 'Episode');
            const balancedSeasonalItems = interleaveBuckets(
                [seasonalMovieItems, seasonalEpisodeItems],
                HERO_ITEM_LIMIT
            );

            return balancedSeasonalItems.length ? balancedSeasonalItems : seasonalBucket;
        })
        .then(items => {
            if (items.length) return Promise.resolve(items);

            const fallbackTerm = seasonalContext.searchTerms[getDailyIndex(seasonalContext.searchTerms.length)];

            return getItems(userId, {
                Limit: HERO_BUCKET_QUERY_LIMIT,
                Recursive: true,
                Fields: HERO_FIELDS,
                ImageTypeLimit: 1,
                EnableImageTypes: 'Primary,Backdrop,Logo',
                EnableTotalRecordCount: false,
                IncludeItemTypes: 'Movie,Episode',
                SortBy: 'CommunityRating,CriticRating,DateCreated',
                SortOrder: 'Descending',
                SearchTerm: fallbackTerm
            }).then(result => sortByTrending(result.Items || []));
        })
        .then(items => getCinematicItems(
            apiClient,
            userId,
            items,
            'seasonal',
            seasonalContext.label,
            HERO_ITEM_LIMIT,
            false
        ))
        .then(items => items.slice(0, HERO_ITEM_LIMIT));

    return withTimeout(seasonalLookup, SEASONAL_LOOKUP_TIMEOUT_MS, []);
}

export function loadHeroItems(apiClient: HeroApiClient, userId: string) {
    return Promise.all([
        getTrendingHeroItems(apiClient, userId).catch(() => []),
        getResumableHeroItems(apiClient, userId)
            .then(result => getCinematicItems(
                apiClient,
                userId,
                result.Items || [],
                'continue',
                undefined,
                HERO_ITEM_LIMIT,
                false
            ))
            .catch(() => []),
        getSeasonalHeroItems(apiClient, userId).catch(() => [])
    ])
        .then(([featuredItems, continueItems, seasonalItems]) => balanceHeroItems([
            ...seasonalItems,
            ...featuredItems,
            ...continueItems
        ]));
}

function createHeroFeaturedPayload(apiClient: HeroApiClient, userId: string): Promise<FeaturedPayload> {
    return loadHeroItems(apiClient, userId)
        .then(heroItems => ({
            heroItems,
            sectionItems: {}
        }));
}

export function useHeroItems(
    apiClient?: HeroApiClient,
    user?: { Id?: string },
    featuredContentPromise?: Promise<FeaturedPayload>
) {
    const [items, setItems] = useState<HeroItem[]>([]);

    useEffect(() => {
        if (!apiClient || !user?.Id) {
            setItems([]);
            return;
        }

        const userId = user.Id;
        let disposed = false;

        const loadContent = (contentPromise: Promise<FeaturedPayload>) => contentPromise
            .then(payload => {
                if (!disposed) {
                    setItems(toHeroItems(payload.heroItems));
                }
            })
            .catch((err: unknown) => {
                console.warn('[PTV Hero] Failed loading hero items', err);
                if (!disposed) {
                    setItems([]);
                }
            });
        const getHeroFeaturedContent = () => getFeaturedContent(() => createHeroFeaturedPayload(apiClient, userId));
        const handleCacheUpdated = () => {
            void loadContent(getHeroFeaturedContent());
        };

        void loadContent(featuredContentPromise || getHeroFeaturedContent());
        window.addEventListener(FEATURED_CACHE_UPDATED_EVENT, handleCacheUpdated);

        return () => {
            disposed = true;
            window.removeEventListener(FEATURED_CACHE_UPDATED_EVENT, handleCacheUpdated);
        };
    }, [apiClient, featuredContentPromise, user?.Id]);

    return items;
}
