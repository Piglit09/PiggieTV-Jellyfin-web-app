import { dispatchPtvCustomEvent, on } from '../../core/events';
import { PTV_BRANDING, PTV_EVENTS, PTV_ROUTES, PTV_SERVICES, PTV_TIMERS } from '../../core/config';
import { registerModule } from '../../core/lifecycle';
import { watchDom } from '../../core/observer';

import './request.scss';

const REQUEST_ROUTE = PTV_ROUTES.request;
const REQUEST_FALLBACK_ROUTE = PTV_ROUTES.requestFallback;
const REQUEST_SAFE_ROUTE = PTV_ROUTES.requestSafe;
const REQUEST_URL = PTV_SERVICES.requestPortalUrl;
const REQUEST_VIEW_SELECTOR = '[data-ptv-request-view="true"]';
const REQUEST_TRIGGER_SELECTOR = [
    '[data-ptv-request-trigger="true"]',
    '[data-ptv-nav-id="request"]',
    '.ptv-top-tab-request',
    `a[href="${REQUEST_ROUTE}"]`,
    `a[href="${REQUEST_FALLBACK_ROUTE}"]`
].join(',');
const REQUEST_LOAD_TIMEOUT = PTV_TIMERS.requestLoadTimeoutMs;
const REQUEST_OPEN_EVENT = PTV_EVENTS.requestOpen;
const REQUEST_CLOSE_EVENT = PTV_EVENTS.requestClose;
const REQUEST_STATE_EVENT = PTV_EVENTS.requestStateChange;

let requestViewScheduled = false;
let requestLoadTimer = null;
let lastSafeUrl = '';

function normalizeRequestTriggers() {
    document.querySelectorAll(REQUEST_TRIGGER_SELECTOR).forEach((trigger) => {
        trigger.dataset.ptvRequestTrigger = 'true';

        if (trigger instanceof HTMLAnchorElement) {
            trigger.setAttribute('href', REQUEST_SAFE_ROUTE);
            trigger.removeAttribute('target');
            trigger.removeAttribute('rel');
            trigger.removeAttribute('data-ptv-external');
        }
    });
}

function isRequestRoute() {
    const hash = window.location.hash || '';

    return hash === REQUEST_ROUTE || hash === REQUEST_FALLBACK_ROUTE;
}

function getCurrentUrl() {
    return `${window.location.pathname}${window.location.search}${window.location.hash || ''}`;
}

function getFallbackSafeUrl() {
    return `${window.location.pathname}${window.location.search}${REQUEST_SAFE_ROUTE}`;
}

function rememberSafeRoute() {
    if (isRequestRoute()) return;

    lastSafeUrl = getCurrentUrl();
}

function replaceRequestHashWithSafeRoute() {
    if (!isRequestRoute()) return;

    window.history.replaceState(window.history.state, '', lastSafeUrl || getFallbackSafeUrl());
}

function getRequestView() {
    const views = Array.from(document.querySelectorAll(REQUEST_VIEW_SELECTOR));
    const [view, ...extraViews] = views;

    extraViews.forEach(extraView => {
        extraView.remove();
    });

    return view;
}

function setRequestState(view, state) {
    view.dataset.ptvRequestState = state;

    const loading = view.querySelector('.ptv-request-loading');
    const fallback = view.querySelector('.ptv-request-fallback');

    if (loading instanceof HTMLElement) {
        loading.hidden = state !== 'loading';
    }

    if (fallback instanceof HTMLElement) {
        fallback.hidden = state !== 'fallback';
    }
}

function clearRequestTimer() {
    if (!requestLoadTimer) return;

    window.clearTimeout(requestLoadTimer);
    requestLoadTimer = null;
}

function showRequestFallback(view) {
    clearRequestTimer();
    setRequestState(view, 'fallback');
}

function syncRequestNavigationState(isActive) {
    const wasActive = document.documentElement.classList.contains('ptv-request-active');

    document.documentElement.classList.toggle('ptv-request-active', isActive);
    document.body.classList.toggle('ptv-request-active', isActive);

    document
        .querySelectorAll('.ptv-top-tab-request, [data-ptv-nav-id="request"]')
        .forEach((element) => {
            element.classList.toggle('emby-tab-button-active', isActive);
            element.classList.toggle('ptv-nav-link-active', isActive);
            element.classList.toggle('ptv-sidebar-item-active', isActive);
            element.classList.toggle('ptv-request-tab-active', isActive);
            element.setAttribute('aria-selected', String(isActive));
        });

    if (wasActive === isActive) return;

    dispatchPtvCustomEvent(REQUEST_STATE_EVENT, { isActive });
}

function createFallbackLink(className) {
    const link = document.createElement('a');

    link.className = className;
    link.dataset.ptvRequestExternal = 'true';
    link.href = REQUEST_URL;
    link.target = '_blank';
    link.rel = 'noopener noreferrer';
    link.textContent = 'Open Request Portal';

    return link;
}

function closeRequestView(options = {}) {
    const shouldUseHistory = options.useHistory !== false;

    if (shouldUseHistory && window.history.state?.ptvRequestActive) {
        window.history.back();
        return;
    }

    clearRequestTimer();
    getRequestView()?.remove();
    syncRequestNavigationState(false);
}

function createRequestView() {
    const view = document.createElement('section');
    const header = document.createElement('div');
    const title = document.createElement('h1');
    const actions = document.createElement('div');
    const closeButton = document.createElement('button');
    const frameShell = document.createElement('div');
    const loading = document.createElement('div');
    const fallback = document.createElement('div');
    const fallbackTitle = document.createElement('h2');
    const fallbackText = document.createElement('p');
    const iframe = document.createElement('iframe');

    view.className = 'ptv-request-page';
    view.dataset.ptvRequestView = 'true';
    view.dataset.ptvRequestState = 'loading';
    view.setAttribute('aria-label', 'Request Portal');

    header.className = 'ptv-request-header';
    title.className = 'ptv-request-title';
    title.textContent = 'Request';
    actions.className = 'ptv-request-actions';
    closeButton.type = 'button';
    closeButton.className = 'ptv-request-close ptv-button ptv-button-ghost';
    closeButton.textContent = 'Close';
    closeButton.addEventListener('click', () => {
        closeRequestView();
    });
    actions.append(createFallbackLink('ptv-request-open-link ptv-button ptv-button-ghost'), closeButton);
    header.append(title, actions);

    frameShell.className = 'ptv-request-frame-shell';

    loading.className = 'ptv-request-state ptv-request-loading';
    loading.textContent = 'Loading request portal...';

    fallback.className = 'ptv-request-state ptv-request-fallback';
    fallback.hidden = true;
    fallbackTitle.textContent = 'Request portal could not be embedded';
    fallbackText.textContent = 'Your browser or the request portal may be blocking embedded access.';
    fallback.append(fallbackTitle, fallbackText, createFallbackLink('ptv-request-fallback-link ptv-button ptv-button-primary'));

    iframe.className = 'ptv-request-frame';
    iframe.src = REQUEST_URL;
    iframe.title = PTV_BRANDING.requestPortalTitle;
    iframe.loading = 'eager';
    iframe.referrerPolicy = 'no-referrer-when-downgrade';
    iframe.sandbox = 'allow-forms allow-popups allow-popups-to-escape-sandbox allow-same-origin allow-scripts';
    iframe.allow = 'fullscreen; clipboard-write';

    iframe.addEventListener('load', () => {
        clearRequestTimer();
        setRequestState(view, 'loaded');
    });

    iframe.addEventListener('error', () => {
        showRequestFallback(view);
    });

    frameShell.append(loading, fallback, iframe);
    view.append(header, frameShell);

    requestLoadTimer = window.setTimeout(() => {
        if (view.dataset.ptvRequestState === 'loading') {
            showRequestFallback(view);
        }
    }, REQUEST_LOAD_TIMEOUT);

    return view;
}

function openRequestView(options = {}) {
    replaceRequestHashWithSafeRoute();
    syncRequestNavigationState(true);

    if (options.pushHistory !== false && !window.history.state?.ptvRequestActive) {
        window.history.pushState({
            ...(window.history.state || {}),
            ptvRequestActive: true
        }, '', getCurrentUrl());
    }

    const existingView = getRequestView();

    if (existingView) {
        return;
    }

    document.body.append(createRequestView());
}

function registerRequestApi() {
    window.PTV = window.PTV || {};
    window.PTV.openRequestPortal = () => openRequestView();
    window.PTV.closeRequestPortal = () => closeRequestView();
}

function ensureRequestView() {
    if (isRequestRoute()) {
        openRequestView({
            pushHistory: false
        });
        return;
    }

    rememberSafeRoute();

    if (getRequestView() && window.history.state?.ptvRequestActive) {
        syncRequestNavigationState(true);
        return;
    }

    if (getRequestView() && !window.history.state?.ptvRequestActive) {
        closeRequestView({
            useHistory: false
        });
    }
}

function scheduleRequestView() {
    if (requestViewScheduled) return;

    requestViewScheduled = true;

    window.requestAnimationFrame(() => {
        requestViewScheduled = false;
        normalizeRequestTriggers();
        ensureRequestView();
    });
}

function handleRequestClick(event) {
    const trigger = event.target?.closest?.(REQUEST_TRIGGER_SELECTOR);

    if (!trigger || trigger.closest?.('[data-ptv-request-external="true"]')) return;

    event.preventDefault();
    event.stopPropagation();
    event.stopImmediatePropagation?.();
    openRequestView();
}

function handleRequestPopState() {
    if (window.history.state?.ptvRequestActive) return;

    if (getRequestView()) {
        closeRequestView({
            useHistory: false
        });
    }

    scheduleRequestView();
}

watchDom(scheduleRequestView);
document.addEventListener('click', handleRequestClick, true);
window.addEventListener(REQUEST_OPEN_EVENT, () => openRequestView());
window.addEventListener(REQUEST_CLOSE_EVENT, () => closeRequestView());
window.addEventListener('hashchange', scheduleRequestView);
window.addEventListener('popstate', handleRequestPopState);

on('routechange', scheduleRequestView);

registerModule({
    density: 'comfortable',
    features: ['request'],
    layout: 'embedded',
    name: 'request',
    route: {
        density: 'comfortable',
        id: 'request',
        layout: 'embedded',
        navigationItemId: 'request',
        owner: 'request',
        pageType: 'request',
        pattern: () => document.documentElement.classList.contains('ptv-request-active'),
        surface: 1
    },
    surface: 1,
    widgets: [
        {
            density: 'comfortable',
            id: 'request-iframe',
            surface: 1,
            type: 'embedded-app'
        }
    ]
});

registerRequestApi();
scheduleRequestView();
