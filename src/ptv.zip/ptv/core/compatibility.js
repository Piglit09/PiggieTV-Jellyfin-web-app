const TV_CLIENT_PATTERN = /(aft|fire tv|roku|tizen|web0s|webos|smart-tv|smarttv|hbbtv|netcast|viera|bravia|crkey|appletv|xbox|playstation)/i;
const MOBILE_CLIENT_PATTERN = /(android|iphone|ipad|ipod|mobile)/i;

function supportsBackdropFilter() {
    const style = document.documentElement.style;

    return 'backdropFilter' in style || 'webkitBackdropFilter' in style;
}

function hasCoarsePointer() {
    if (typeof window.matchMedia !== 'function') return false;

    return window.matchMedia('(pointer: coarse)').matches
        || window.matchMedia('(hover: none)').matches;
}

function applyCompatibilityClasses() {
    const root = document.documentElement;
    const userAgent = navigator.userAgent || '';
    const isTvClient = TV_CLIENT_PATTERN.test(userAgent);
    const isMobileClient = MOBILE_CLIENT_PATTERN.test(userAgent);
    const isCoarsePointer = hasCoarsePointer();
    const isLowPowerClient = isTvClient || isMobileClient || isCoarsePointer;

    root.classList.toggle('ptv-client-tv', isTvClient);
    root.classList.toggle('ptv-client-mobile', isMobileClient);
    root.classList.toggle('ptv-client-coarse-pointer', isCoarsePointer);
    root.classList.toggle('ptv-client-low-power', isLowPowerClient);
    root.classList.toggle('ptv-no-backdrop-filter', !supportsBackdropFilter());
}

applyCompatibilityClasses();
