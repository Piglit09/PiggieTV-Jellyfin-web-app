import { emit, on } from './events';
import { schedule } from './scheduler';
import { getPtvRouteClassNames, getPtvRouteOwnership } from '../shell/routes';

const browserHistory = window.history;

let currentPath = '';
let patchedHistory = false;

export function getRoute() {
    return getPtvRouteOwnership(window.location);
}

function applyRouteClasses(route) {
    const root = document.documentElement;

    root.classList.remove(...getPtvRouteClassNames());
    root.classList.add(route.className);
    root.dataset.ptvRouteOwner = route.owner;
    root.dataset.ptvRoutePageType = route.pageType;
    root.dataset.ptvRouteLayout = route.layout;
    root.dataset.ptvRouteDensity = route.density;
    root.dataset.ptvRouteElevation = String(route.elevation);
    root.dataset.ptvNavSection = route.navigation.activeSectionId || '';
    root.dataset.ptvNavItem = route.navigation.activeItemId || '';
}

export function checkRoute(options = {}) {
    const route = getRoute();

    const routeKey = `${route.full}|${route.pageType}|${route.owner}|${route.layout}|${route.features.join(',')}`;

    if (!options.force && routeKey === currentPath) {
        return route;
    }

    currentPath = routeKey;
    applyRouteClasses(route);
    emit('routechange', route);

    return route;
}

export function scheduleRouteCheck(force = false) {
    schedule('route-check', () => checkRoute({ force }));
}

function patchHistory() {
    if (patchedHistory) return;

    patchedHistory = true;

    const originalPushState = browserHistory.pushState;
    const originalReplaceState = browserHistory.replaceState;

    browserHistory.pushState = function (...args) {
        const result = originalPushState.apply(this, args);
        scheduleRouteCheck();
        return result;
    };

    browserHistory.replaceState = function (...args) {
        const result = originalReplaceState.apply(this, args);
        scheduleRouteCheck();
        return result;
    };
}

on('moduleregistered', () => {
    scheduleRouteCheck(true);
});

export function startRouter() {
    patchHistory();

    window.addEventListener('hashchange', () => scheduleRouteCheck());
    window.addEventListener('popstate', () => scheduleRouteCheck());

    currentPath = '';
    checkRoute();
}

startRouter();
