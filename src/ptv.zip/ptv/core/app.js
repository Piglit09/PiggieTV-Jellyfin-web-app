import { ready, emit } from './events';
import { once } from '../utils/guards';
import './compatibility';
import './lifecycle';
import { scheduleRouteCheck } from './router';

import './observer';
import './jellyfin-hooks';
import './theme';
import './shell';
import '../instrumentation';
import '../primitives/stockPatterns';
import '../shell/overlays';
import '../modules';

ready(() => {
    once('ptv-app', () => {
        document.documentElement.classList.add('ptv-ready');
        emit('ready');
        scheduleRouteCheck(true);

        console.info('[PiggieTV] Runtime started');
    });
});
