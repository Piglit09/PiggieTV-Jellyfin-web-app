const isDev = window.location.hostname === 'localhost';

export const PTV_BRANDING = {
    appName: 'PiggieTV',
    loginDescription: 'Movies, shows, anime, and late-night comfort in one place.',
    loginTaglineHtml: 'MOVIES &bull; TV SHOWS &bull; ANIME',
    loginWelcome: 'Welcome back',
    requestPortalTitle: 'PiggieTV Request Portal',
    welcomeDescription: 'Welcome to PiggieTV'
} as const;

export const PTV_ASSETS = {
    backgrounds: {
        login: 'assets/backgrounds/PiggieTVBG.png'
    },
    backgroundsBase: 'assets/backgrounds',
    iconBase: 'assets/icons',
    icons: {
        discord: 'assets/icons/discord.svg'
    },
    logoBase: 'assets/logo',
    logos: {
        bannerLight: 'assets/logo/banner-light.png',
        favicon: 'assets/logo/favicon.png',
        icon: 'assets/logo/icon.png',
        sidebar: 'assets/logo/sidebar-logo.png'
    }
} as const;

export const PTV_SERVICES = {
    accountUrl: 'https://signup.piggietv.com/my/account',
    booksUrl: 'https://books.piggietv.com',
    discordUrl: 'https://discord.gg/FbtexGYau',
    gamesUrl: 'https://emu.piggietv.com',
    requestPortalUrl: 'https://request.piggietv.com',
    signUpUrl: 'https://signup.piggietv.com/invite/ysBDodSMPv5fFMz9GPMxUL'
} as const;

export const PTV_ROUTES = {
    displayPreferences: '#/mypreferencesdisplay',
    favorites: '#/home?tab=1',
    favoritesLegacy: '#/favorites',
    home: '#/home',
    homeHtml: '#/home.html',
    profilePreferences: '#/mypreferencesmenu',
    randomItem: '#/list?sortBy=Random',
    request: '#/ptv/request',
    requestFallback: '#/request',
    requestSafe: '#/home',
    search: '#/search'
} as const;

export const PTV_EVENTS = {
    featuredCacheUpdated: 'ptv-featured-cache-updated',
    requestClose: 'ptv:request:close',
    requestOpen: 'ptv:request:open',
    requestStateChange: 'ptv:request:statechange',
    themeChange: 'ptv:themechange'
} as const;

export const PTV_CACHE = {
    featuredContentKey: 'ptv:featured-content:v1',
    featuredContentTtlMs: 12 * 60 * 60 * 1000,
    featuredContentVersion: 1
} as const;

export const PTV_TIMERS = {
    requestLoadTimeoutMs: 8000
} as const;

export const PTV_FEATURE_FLAGS = {
    embeddedRequestPortal: true,
    featuredContentCache: true,
    ptvIconEngine: true
} as const;

export const PTV_CONFIG = {
    assets: PTV_ASSETS,
    branding: PTV_BRANDING,
    cache: PTV_CACHE,
    events: PTV_EVENTS,
    featureFlags: PTV_FEATURE_FLAGS,
    routes: PTV_ROUTES,
    serverUrl: isDev ?
        // eslint-disable-next-line sonarjs/no-clear-text-protocols
        'http://10.16.0.50:8096' :
        window.location.origin,
    services: PTV_SERVICES,
    timers: PTV_TIMERS
} as const;
